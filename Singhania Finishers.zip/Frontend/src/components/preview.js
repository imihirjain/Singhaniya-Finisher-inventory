import React from 'react'

const preview = () => {
  return (
    <div>
        <h1>
            Preview
        </h1>
      
    </div>
  )
}

export default preview;
